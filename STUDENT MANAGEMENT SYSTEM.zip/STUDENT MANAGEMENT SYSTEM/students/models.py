from django.db import models

# Create your models here.
from django.db import models

class Student(models.Model):
    admission_no = models.CharField(max_length=20)
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    department = models.CharField(max_length=100)
    semester = models.IntegerField()

    parent_name = models.CharField(max_length=100)
    parent_phone = models.CharField(max_length=15)

    email = models.EmailField()
    phone = models.CharField(max_length=15)
    address = models.TextField()

    academic_fee = models.DecimalField(max_digits=10, decimal_places=2)
    bus_fee = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name
    

class Teacher(models.Model):
    teacher_id = models.CharField(max_length=20)
    name = models.CharField(max_length=100)

    course = models.ForeignKey(
        'Course',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    department = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    

class Course(models.Model):
    course_code = models.CharField(max_length=20)
    course_name = models.CharField(max_length=100)
    semester = models.IntegerField()

    def __str__(self):
        return self.course_name

class Notice(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateField()

    def __str__(self):
        return self.title


class Marks(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    subject = models.CharField(max_length=100)
    marks = models.IntegerField()

    
class Attendance(models.Model):

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE
    )

    date = models.DateField()

    status = models.CharField(
        max_length=10
    )

    def __str__(self):
        return self.student.name
    
class Fee(models.Model):

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE
    )

    academic_fee = models.IntegerField()
    bus_fee = models.IntegerField()
    paid = models.IntegerField()

    def balance(self):
        return (
            self.academic_fee +
            self.bus_fee -
            self.paid
        )