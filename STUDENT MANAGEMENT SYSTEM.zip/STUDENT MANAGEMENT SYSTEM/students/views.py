
from django.shortcuts import render
from .models import Student
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404

def home(request):
    return render(request, 'home.html')

def students_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})

def login_view(request):
    return render(request,'login.html')

def admin_login(request):

    if request.method == "POST":

        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            login(request, user)

            return redirect('admin_dashboard')

    return render(
        request,
        'admin_login.html'
    )

def student_login(request):
    return render(request,'student_login.html')
    

def superadmin_login(request):
    return render(request,'superadmin_login.html')

def student_dashboard(request):
    return render(request,'student_dashboard.html')

from .models import Student, Teacher, Notice

@login_required
def admin_dashboard(request):

    total_students = Student.objects.count()
    total_teachers = Teacher.objects.count()
    total_notices = Notice.objects.count()

    return render(
        request,
        'admin_dashboard.html',
        {
            'total_students': total_students,
            'total_teachers': total_teachers,
            'total_notices': total_notices
        }
    )

def superadmin_dashboard(request):
    return render(request,'superadmin_dashboard.html')

from .models import Student

def students_management(request):
    students = Student.objects.all()

    return render(
        request,
        'students_management.html',
        {'students': students}
    )


from django.shortcuts import render, get_object_or_404
from .models import Student

def student_profile(request, student_id):
    student = get_object_or_404(
        Student,
        id=student_id
    )

    return render(
        request,
        'student_profile.html',
        {'student': student}
    )

from django.shortcuts import redirect

def edit_student(request, student_id):

    student = get_object_or_404(
        Student,
        id=student_id
    )

    if request.method == "POST":

        student.name = request.POST['name']
        student.department = request.POST['department']
        student.semester = request.POST['semester']
        student.phone = request.POST['phone']
        student.email = request.POST['email']

        student.save()

        return redirect(
            'student_profile',
            student_id=student.id
        )

    return render(
        request,
        'edit_student.html',
        {'student': student}
    )


from django.shortcuts import redirect

def delete_student(request, id):
    student = Student.objects.get(id=id)
    student.delete()
    return redirect('students_management')


from django.shortcuts import redirect

def add_student(request):

    if request.method == "POST":

        Student.objects.create(
            admission_no=request.POST['admission_no'],
            name=request.POST['name'],
            age=request.POST['age'],
            gender=request.POST['gender'],
            department=request.POST['department'],
            semester=request.POST['semester'],
            parent_name=request.POST['parent_name'],
            parent_phone=request.POST['parent_phone'],
            email=request.POST['email'],
            phone=request.POST['phone'],
            address=request.POST['address'],
            academic_fee=request.POST['academic_fee'],
            bus_fee=request.POST['bus_fee']
        )

        return redirect('students_management')

    return render(request,'add_student.html')


from .models import Teacher

def teachers_management(request):
    teachers = Teacher.objects.all()

    return render(
        request,
        'teachers_management.html',
        {'teachers': teachers}
    )


from .models import Teacher, Course

def add_teacher(request):

    if request.method == "POST":

        course = Course.objects.get(
            id=request.POST['course']
        )

        Teacher.objects.create(
            teacher_id=request.POST['teacher_id'],
            name=request.POST['name'],
            course=course,
            department=request.POST['department'],
            subject=request.POST['subject'],
            phone=request.POST['phone'],
            email=request.POST['email']
        )

        return redirect('teachers_management')

    courses = Course.objects.all()

    return render(
        request,
        'add_teacher.html',
        {'courses': courses}
    )

def teacher_profile(request,id):

    teacher = Teacher.objects.get(id=id)

    return render(
        request,
        'teacher_profile.html',
        {'teacher': teacher}
    )


from .models import Teacher, Course

def edit_teacher(request,id):

    teacher = Teacher.objects.get(id=id)

    if request.method == "POST":

        teacher.teacher_id = request.POST['teacher_id']
        teacher.name = request.POST['name']
        teacher.department = request.POST['department']
        teacher.subject = request.POST['subject']
        teacher.phone = request.POST['phone']
        teacher.email = request.POST['email']

        if 'course' in request.POST:
            teacher.course = Course.objects.get(
                id=request.POST['course']
            )

        teacher.save()

        return redirect('teachers_management')

    courses = Course.objects.all()

    return render(
        request,
        'edit_teacher.html',
        {
            'teacher': teacher,
            'courses': courses
        }
    )
 

def delete_teacher(request,id):

    teacher = Teacher.objects.get(id=id)

    teacher.delete()

    return redirect('teachers_management')



from .models import Course

def courses_management(request):

    courses = Course.objects.all()

    return render(
        request,
        'courses_management.html',
        {'courses': courses}
    )


def add_course(request):

    if request.method == "POST":

        Course.objects.create(
            course_code=request.POST['course_code'],
            course_name=request.POST['course_name'],
            semester=request.POST['semester']
        )

        return redirect('courses_management')

    return render(request,'add_course.html')


def course_profile(request,id):

    course = Course.objects.get(id=id)

    return render(
        request,
        'course_profile.html',
        {'course': course}
    )


def edit_course(request,id):

    course = Course.objects.get(id=id)

    if request.method == "POST":

        course.course_code = request.POST['course_code']
        course.course_name = request.POST['course_name']
        course.semester = request.POST['semester']

        course.save()

        return redirect('courses_management')

    return render(
        request,
        'edit_course.html',
        {'course': course}
    )


def delete_course(request,id):

    course = Course.objects.get(id=id)

    course.delete()

    return redirect('courses_management')

from .models import Notice

def notices_management(request):

    notices = Notice.objects.all()

    return render(
        request,
        'notices_management.html',
        {'notices': notices}
    )


def add_notice(request):

    if request.method == "POST":

        Notice.objects.create(
            title=request.POST['title'],
            description=request.POST['description'],
            date=request.POST['date']
        )

        return redirect('notices_management')

    return render(request,'add_notice.html')


def delete_notice(request,id):

    notice = Notice.objects.get(id=id)

    notice.delete()

    return redirect('notices_management')

from .models import Notice

def notice_profile(request, id):

    notice = Notice.objects.get(id=id)

    return render(
        request,
        'notice_profile.html',
        {'notice': notice}
    )

def student_notices(request):

    notices = Notice.objects.all().order_by('-date')

    return render(
        request,
        'student_notices.html',
        {'notices': notices}
    )


def student_notice_profile(request, id):

    notice = Notice.objects.get(id=id)

    return render(
        request,
        'student_notice_profile.html',
        {'notice': notice}
    )


from .models import Marks

def marks_management(request):

    marks = Marks.objects.all()

    total_records = marks.count()

    highest_mark = 0
    average_mark = 0
    top_performers = 0

    if total_records > 0:

        highest_mark = marks.order_by(
            '-marks'
        ).first().marks

        total_marks = sum(
            mark.marks for mark in marks
        )

        average_mark = round(
            total_marks / total_records,
            2
        )

        top_performers = marks.filter(
            marks__gte=90
        ).count()

    return render(
    request,
    'marks_management.html',
    {
        'marks': marks,
        'total_records': total_records,
        'highest_mark': highest_mark,
        'average_mark': average_mark,
        'top_performers': top_performers
    }
)

def add_marks(request):

    students = Student.objects.all()

    if request.method == "POST":

        student = Student.objects.get(
            id=request.POST['student']
        )

        Marks.objects.create(
            student=student,
            subject=request.POST['subject'],
            marks=request.POST['marks']
        )

        return redirect('marks_management')

    return render(
        request,
        'add_marks.html',
        {'students': students}
    )


def delete_marks(request,id):

    mark = Marks.objects.get(id=id)

    mark.delete()

    return redirect('marks_management')


def marks_profile(request, id):

    mark = Marks.objects.get(id=id)

    return render(
        request,
        'marks_profile.html',
        {'mark': mark}
    )

from .models import Student, Marks

def student_result(request, student_id):

    student = Student.objects.get(
        id=student_id
    )

    marks = Marks.objects.filter(
        student=student
    )


    total_subjects = marks.count()

    total_marks = sum(
        mark.marks for mark in marks
    )

    highest_mark = 0
    average_mark = 0

    if total_subjects > 0:

        highest_mark = max(
            mark.marks for mark in marks
        )

        average_mark = round(
            total_marks / total_subjects,
            2
        )

    return render(
        request,
        'student_result.html',
        {
            'student': student,
            'marks': marks,
            'total_subjects': total_subjects,
            'total_marks': total_marks,
            'highest_mark': highest_mark,
            'average_mark': average_mark
        }
    )

from .models import Attendance

def add_attendance(request):

    students = Student.objects.all()

    if request.method == "POST":

        student = Student.objects.get(
            id=request.POST['student']
        )

        Attendance.objects.create(
            student=student,
            date=request.POST['date'],
            status=request.POST['status']
        )

        return redirect('attendance_management')

    return render(
        request,
        'add_attendance.html',
        {'students': students}
    )



def attendance_management(request):

    attendance = Attendance.objects.all()

    return render(
        request,
        'attendance_management.html',
        {'attendance': attendance}
    )

def fees_management(request):

    students = Student.objects.all()

    return render(
        request,
        'fees_management.html',
        {'students': students}
    )


def fee_profile(request, id):

    student = Student.objects.get(id=id)

    total_fee = (
        student.academic_fee +
        student.bus_fee
    )

    return render(
        request,
        'fee_profile.html',
        {
            'student': student,
            'total_fee': total_fee
        }
    )


from .models import Fee

def fees_management(request):

    fees = Fee.objects.all()

    return render(
        request,
        'fees_management.html',
        {'fees': fees}
    )


def add_fee(request):

    students = Student.objects.all()

    if request.method == "POST":

        student = Student.objects.get(
            id=request.POST['student']
        )

        academic_fee = int(
            request.POST['academic_fee']
        )

        bus_fee = int(
            request.POST['bus_fee']
        )

        Fee.objects.create(
            student=student,
            academic_fee=academic_fee,
            bus_fee=bus_fee,
            paid=0
        )

        return redirect('fees_management')

    return render(
        request,
        'add_fee.html',
        {'students': students}
    )


def delete_fee(request,id):

    fee = Fee.objects.get(id=id)

    fee.delete()

    return redirect('fees_management')

def edit_attendance(request,id):

    attendance = Attendance.objects.get(id=id)

    if request.method == "POST":

        attendance.date = request.POST['date']
        attendance.status = request.POST['status']

        attendance.save()

        return redirect('attendance_management')

    return render(
        request,
        'edit_attendance.html',
        {'attendance': attendance}
    )

def edit_fee(request,id):

    fee = Fee.objects.get(id=id)

    if request.method == "POST":

        fee.academic_fee = request.POST['academic_fee']
        fee.bus_fee = request.POST['bus_fee']
        fee.paid = request.POST['paid']

        fee.save()

        return redirect('fees_management')

    return render(
        request,
        'edit_fee.html',
        {'fee': fee}
    )

def edit_attendance(request, id):

    attendance = Attendance.objects.get(id=id)

    if request.method == "POST":

        attendance.date = request.POST['date']
        attendance.status = request.POST['status']

        attendance.save()

        return redirect('attendance_management')

    return render(
        request,
        'edit_attendance.html',
        {'attendance': attendance}
    )

def delete_attendance(request, id):

    attendance = Attendance.objects.get(id=id)

    attendance.delete()

    return redirect('attendance_management')

def edit_fee(request, id):

    fee = Fee.objects.get(id=id)

    if request.method == "POST":

        fee.academic_fee = request.POST['academic_fee']
        fee.bus_fee = request.POST['bus_fee']
        fee.paid = request.POST['paid']

        fee.save()

        return redirect('fees_management')

    return render(
        request,
        'edit_fee.html',
        {'fee': fee}
    )

def logout_view(request):

    logout(request)

    return redirect('login')

def edit_fee(request,id):

    fee = Fee.objects.get(id=id)

    if request.method == "POST":

        fee.academic_fee = request.POST['academic_fee']
        fee.bus_fee = request.POST['bus_fee']
        fee.paid = request.POST['paid']

        fee.save()

        return redirect('fees_management')

    return render(
        request,
        'edit_fee.html',
        {'fee': fee}
    )