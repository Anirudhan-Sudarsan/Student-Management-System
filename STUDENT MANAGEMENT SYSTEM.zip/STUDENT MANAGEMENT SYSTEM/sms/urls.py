"""
URL configuration for sms project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from students.views import admin_login
from students.views import home
from students.views import students_list
from django.contrib.auth.decorators import login_required
from students.views import (
    home,
    students_list,
    admin_login
)
from students.views import student_dashboard
from students.views import admin_dashboard
from students.views import superadmin_dashboard
from students.views import students_management
from students.views import student_profile
from students.views import edit_student
from students.views import delete_student
from students.views import add_student
from students.views import teachers_management
from students import views

urlpatterns = [
    path(
    'edit-course/<int:id>/',
    views.edit_course,
    name='edit_course'
),

path(
    'notices-management/',
    views.notices_management,
    name='notices_management'
),

path(
    'notice-profile/<int:id>/',
    views.notice_profile,
    name='notice_profile'
),

path(
    'add-notice/',
    views.add_notice,
    name='add_notice'
),

path(
    'delete-notice/<int:id>/',
    views.delete_notice,
    name='delete_notice'
),

path(
    'delete-course/<int:id>/',
    views.delete_course,
    name='delete_course'
),
    path(
    'courses-management/',
    views.courses_management,
    name='courses_management'
),

path(
    'add-course/',
    views.add_course,
    name='add_course'
),

path(
    'course-profile/<int:id>/',
    views.course_profile,
    name='course_profile'
),


    path('add-student/',add_student,name='add_student'),
    path('delete-student/<int:id>/',delete_student,name='delete_student'),
    path('', views.admin_login, name='login'),

    path('admin-login/', admin_login, name='admin_login'),

    path('home/', home, name='home'),

    path('students/', students_list, name='students'),

    path('admin/', admin.site.urls),

    path('student-dashboard/', student_dashboard, name='student_dashboard'),
    path('admin-dashboard/', admin_dashboard, name='admin_dashboard'),

    path('superadmin-dashboard/',superadmin_dashboard,name='superadmin_dashboard'),

    path(
    'students-management/',students_management,name='students_management'),

    path(
    'student-profile/<int:student_id>/',student_profile,name='student_profile'),

    path('edit-student/<int:student_id>/',edit_student,name='edit_student'),

    path(
    'teachers-management/',
    views.teachers_management,
    name='teachers_management'
),

path(
    'add-teacher/',
    views.add_teacher,
    name='add_teacher'
),

path(
    'teacher-profile/<int:id>/',
    views.teacher_profile,
    name='teacher_profile'
),

path(
    'edit-teacher/<int:id>/',
    views.edit_teacher,
    name='edit_teacher'
),

path(
    'delete-teacher/<int:id>/',
    views.delete_teacher,
    name='delete_teacher'
),


path(
    'student-notices/',
    views.student_notices,
    name='student_notices'
),

path(
    'marks-management/',
    views.marks_management,
    name='marks_management'
),

path(
    'add-marks/',
    views.add_marks,
    name='add_marks'
),

path(
    'delete-marks/<int:id>/',
    views.delete_marks,
    name='delete_marks'
),

path(
    'student-notice/<int:id>/',
    views.student_notice_profile,
    name='student_notice_profile'
),

path(
    'marks-profile/<int:id>/',
    views.marks_profile,
    name='marks_profile'
),

path(
    'student-result/<int:student_id>/',
    views.student_result,
    name='student_result'
),

path(
    'attendance-management/',
    views.attendance_management,
    name='attendance_management'
),

path(
    'add-attendance/',
    views.add_attendance,
    name='add_attendance'
),

path(
    'fee-profile/<int:id>/',
    views.fee_profile,
    name='fee_profile'
),

path(
    'fees-management/',
    views.fees_management,
    name='fees_management'
),

path(
    'add-fee/',
    views.add_fee,
    name='add_fee'
),

path(
    'delete-fee/<int:id>/',
    views.delete_fee,
    name='delete_fee'
),


path(
    'delete-attendance/<int:id>/',
    views.delete_attendance,
    name='delete_attendance'
),


path(
    'edit-attendance/<int:id>/',
    views.edit_attendance,
    name='edit_attendance'
),

path(
    'edit-fee/<int:id>/',
    views.edit_fee,
    name='edit_fee'
),

path(
    'logout/',
    views.logout_view,
    name='logout'
),

]